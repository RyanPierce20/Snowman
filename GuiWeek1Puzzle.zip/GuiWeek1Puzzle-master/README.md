# GuiWeek1Puzzle

<b>Description</b><br \>
The base code for the puzzle given on week 1 in CST 238 GUI (Oregon Institute of Technology).

<b>Screenshot of solution</b><br \><br \>
<b>Qt solution</b><br \>
![Alt text](/img/sample_snowman.PNG)
<br \>
<b>Unity solution</b><br \>
![Alt text](/img/example_snowman2.png)

<b>Inspiration</b><br \>
After a few minutes of bickering, we picked Chris Dean's idea to build a snowman.  Other nominations were guizing the internal workings of a compiler, writing your name using only rectangle objects and replicating a lifesize matryoshka doll from the movie Dr. Zhivago (1965).
